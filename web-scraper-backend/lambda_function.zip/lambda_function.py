
import json
import requests
from bs4 import BeautifulSoup
import boto3
import os

def scrape_website(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extract text content
        text_content = soup.get_text()
        title = soup.title.string if soup.title else ""
        
        return {
            "title": title,
            "content": text_content[:1000]  # First 1000 chars for testing
        }
    except Exception as e:
        return {"error": str(e)}

def lambda_handler(event, context):
    try:
        url = event.get('url', '')
        
        if not url:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'URL is required'})
            }
            
        result = scrape_website(url)
        
        return {
            'statusCode': 200,
            'body': json.dumps(result)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
